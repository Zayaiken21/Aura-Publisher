<?php if (!defined('ABSPATH')) exit; get_header(); $term=get_queried_object(); $tpl=aura_bridge_get_template($term->term_id); $m=$tpl['monetization'] ?? []; $ad_every=max(0,(int)($m['archiveAdEvery'] ?? 3)); $ad_h=max(90,(int)($m['archiveAdHeight'] ?? 280)); $linked=!isset($m['linkedImages']) || !empty($m['linkedImages']); ?>
<main id="primary" class="aura-category-takeover">
  <?php echo aura_bridge_render_template($tpl,true); ?>
  <?php if (!empty($tpl['showNativePosts'])): ?>
  <section id="aura-posts" class="aura-native-posts"><div class="aura-container">
    <div class="aura-native-head"><span class="aura-kicker">LATEST</span><h2>Latest from <?php echo esc_html($term->name); ?></h2><p>Fresh articles from this category, pulled directly from WordPress so new posts appear automatically.</p></div>
    <div class="aura-post-grid">
      <?php $aura_i=0; if (have_posts()): while (have_posts()): the_post(); $aura_i++; ?>
      <article <?php post_class('aura-post-card'); ?>>
        <?php if($linked): ?><a class="aura-post-thumb" href="<?php the_permalink(); ?>" aria-label="<?php echo esc_attr(get_the_title()); ?>"><?php if(has_post_thumbnail()) the_post_thumbnail('large',['loading'=>'lazy','decoding'=>'async']); ?></a>
        <?php else: ?><div class="aura-post-thumb"><?php if(has_post_thumbnail()) the_post_thumbnail('large',['loading'=>'lazy','decoding'=>'async']); ?></div><?php endif; ?>
        <div class="aura-post-body"><span class="aura-post-meta"><?php echo esc_html(get_the_date()); ?></span><h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3><p><?php echo esc_html(wp_trim_words(get_the_excerpt(),28)); ?></p><a class="aura-read" href="<?php the_permalink(); ?>">Read article →</a></div>
      </article>
      <?php if($ad_every && $aura_i % $ad_every === 0): ?>
        <aside class="aura-native-ad-slot" style="--aura-ad-h:<?php echo esc_attr($ad_h); ?>px" data-aura-ad-slot="archive-<?php echo esc_attr($aura_i); ?>">
          <?php ob_start(); do_action('aura_archive_ad_slot',$aura_i,$term); $slot=trim(ob_get_clean()); echo $slot!==''?$slot:'<span>ADVERTISEMENT</span>'; ?>
        </aside>
      <?php endif; ?>
      <?php endwhile; else: ?><p>No posts found.</p><?php endif; ?>
    </div>
    <div class="aura-pagination"><?php the_posts_pagination(['mid_size'=>1]); ?></div>
  </div></section>
  <?php endif; ?>
</main>
<?php get_footer(); ?>
