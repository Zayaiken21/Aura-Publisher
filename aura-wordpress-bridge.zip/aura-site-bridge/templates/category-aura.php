<?php if (!defined('ABSPATH')) exit; get_header(); $term=get_queried_object(); $tpl=aura_bridge_get_template($term->term_id); ?>
<main id="primary" class="aura-category-takeover">
  <?php echo aura_bridge_render_template($tpl,true); ?>
  <?php if (!empty($tpl['showNativePosts'])): ?>
  <section id="aura-posts" class="aura-native-posts"><div class="aura-container">
    <div class="aura-native-head"><span class="aura-kicker">LATEST</span><h2>Latest from <?php echo esc_html($term->name); ?></h2></div>
    <div class="aura-post-grid">
      <?php if (have_posts()): while (have_posts()): the_post(); ?>
      <article <?php post_class('aura-post-card'); ?>>
        <a class="aura-post-thumb" href="<?php the_permalink(); ?>" aria-label="<?php echo esc_attr(get_the_title()); ?>"><?php if(has_post_thumbnail()) the_post_thumbnail('large',['loading'=>'lazy']); ?></a>
        <div class="aura-post-body"><span class="aura-post-meta"><?php echo esc_html(get_the_date()); ?></span><h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3><p><?php echo esc_html(wp_trim_words(get_the_excerpt(),28)); ?></p><a class="aura-read" href="<?php the_permalink(); ?>">Read article →</a></div>
      </article>
      <?php endwhile; else: ?><p>No posts found.</p><?php endif; ?>
    </div>
    <div class="aura-pagination"><?php the_posts_pagination(['mid_size'=>1]); ?></div>
  </div></section>
  <?php endif; ?>
</main>
<?php get_footer(); ?>
