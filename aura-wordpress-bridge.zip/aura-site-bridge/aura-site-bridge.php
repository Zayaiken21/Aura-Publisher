<?php
/**
 * Plugin Name: Aura Site Bridge
 * Description: Full WordPress layout bridge for Aura Publisher Pro: category takeovers, resource hubs, affiliate sidebars, template publishing and live diagnostics.
 * Version: 1.0.0
 * Author: Aura Publisher Pro
 */
if (!defined('ABSPATH')) exit;

define('AURA_BRIDGE_VERSION','1.0.0');
define('AURA_BRIDGE_DIR',plugin_dir_path(__FILE__));
define('AURA_BRIDGE_URL',plugin_dir_url(__FILE__));

add_action('init', function(){
  register_term_meta('category','aura_template_json',['type'=>'string','single'=>true,'show_in_rest'=>false,'sanitize_callback'=>'wp_kses_post','auth_callback'=>function(){return current_user_can('edit_posts');}]);
  register_term_meta('category','aura_template_mode',['type'=>'string','single'=>true,'show_in_rest'=>false,'sanitize_callback'=>'sanitize_key','auth_callback'=>function(){return current_user_can('edit_posts');}]);
});

function aura_bridge_can_manage(){ return current_user_can('manage_options') || current_user_can('edit_pages'); }
function aura_bridge_clean_url($url){ return esc_url_raw(trim((string)$url)); }
function aura_bridge_sanitize_affiliate($row){
  return [
    'label'=>sanitize_text_field($row['label'] ?? 'Recommended'),
    'title'=>sanitize_text_field($row['title'] ?? ''),
    'text'=>sanitize_textarea_field($row['text'] ?? ''),
    'url'=>aura_bridge_clean_url($row['url'] ?? ''),
    'image'=>aura_bridge_clean_url($row['image'] ?? ''),
    'cta'=>sanitize_text_field($row['cta'] ?? 'Learn more'),
    'disclosure'=>sanitize_text_field($row['disclosure'] ?? 'Affiliate link'),
  ];
}
function aura_bridge_sanitize_template($in){
  $blocks=[];
  foreach (($in['blocks'] ?? []) as $b){
    $items=[]; foreach (($b['items'] ?? []) as $i) $items[] = sanitize_text_field($i);
    $blocks[]=['type'=>sanitize_key($b['type'] ?? 'grid'),'title'=>sanitize_text_field($b['title'] ?? ''),'text'=>sanitize_textarea_field($b['text'] ?? ''),'items'=>$items,'button'=>sanitize_text_field($b['button'] ?? ''),'url'=>aura_bridge_clean_url($b['url'] ?? '')];
  }
  $aff=[]; foreach (($in['affiliates'] ?? []) as $a) $aff[] = aura_bridge_sanitize_affiliate($a);
  return [
    'name'=>sanitize_text_field($in['name'] ?? ''),
    'eyebrow'=>sanitize_text_field($in['eyebrow'] ?? ''),
    'title'=>sanitize_text_field($in['title'] ?? ''),
    'intro'=>sanitize_textarea_field($in['intro'] ?? ''),
    'hero'=>aura_bridge_clean_url($in['hero'] ?? ''),
    'accent'=>sanitize_hex_color($in['accent'] ?? '#2378d2') ?: '#2378d2',
    'variant'=>sanitize_key($in['variant'] ?? 'editorial'),
    'mode'=>in_array(($in['mode'] ?? 'full'),['full','header'],true)?$in['mode']:'full',
    'blocks'=>$blocks,
    'affiliates'=>$aff,
    'showNativePosts'=>!empty($in['showNativePosts']),
  ];
}
function aura_bridge_get_template($term_id){
  $raw=get_term_meta($term_id,'aura_template_json',true);
  if(!$raw) return null;
  $d=json_decode($raw,true); return is_array($d)?$d:null;
}

add_action('rest_api_init', function(){
  register_rest_route('aura/v1','/status',[
    'methods'=>'GET','permission_callback'=>'aura_bridge_can_manage','callback'=>function(){
      return rest_ensure_response(['ok'=>true,'version'=>AURA_BRIDGE_VERSION,'capabilities'=>['category_takeover'=>true,'affiliate_sidebar'=>true,'resource_templates'=>true,'page_styles'=>true,'diagnostics'=>true]]);
    }
  ]);
  register_rest_route('aura/v1','/category/(?P<id>\d+)/template',[
    'methods'=>'POST','permission_callback'=>'aura_bridge_can_manage','callback'=>function(WP_REST_Request $r){
      $id=(int)$r['id']; $term=get_term($id,'category'); if(!$term || is_wp_error($term)) return new WP_Error('aura_bad_category','Category not found',['status'=>404]);
      $tpl=aura_bridge_sanitize_template((array)$r->get_json_params());
      update_term_meta($id,'aura_template_json',wp_json_encode($tpl));
      update_term_meta($id,'aura_template_mode',$tpl['mode']);
      // Remove legacy CSS-as-description so it can never show as raw text again.
      if (strpos((string)$term->description,'.aura-site-template') !== false || strpos((string)$term->description,'<style') !== false) {
        wp_update_term($id,'category',['description'=>'']);
      }
      return rest_ensure_response(['ok'=>true,'id'=>$id,'mode'=>$tpl['mode'],'link'=>get_category_link($id)]);
    }
  ]);
  register_rest_route('aura/v1','/category/(?P<id>\d+)/template',[
    'methods'=>'DELETE','permission_callback'=>'aura_bridge_can_manage','callback'=>function(WP_REST_Request $r){ delete_term_meta((int)$r['id'],'aura_template_json'); delete_term_meta((int)$r['id'],'aura_template_mode'); return ['ok'=>true]; }
  ]);
  register_rest_route('aura/v1','/diagnostics',[
    'methods'=>'GET','permission_callback'=>'aura_bridge_can_manage','callback'=>function(){
      global $wp_version; $theme=wp_get_theme();
      return rest_ensure_response(['ok'=>true,'wordpress'=>$wp_version,'php'=>PHP_VERSION,'theme'=>$theme->get('Name'),'theme_version'=>$theme->get('Version'),'permalinks'=>(bool)get_option('permalink_structure'),'rest'=>true,'uploads'=>wp_upload_dir()['basedir'],'max_upload'=>wp_max_upload_size()]);
    }
  ]);
});

add_action('wp_enqueue_scripts', function(){
  $load = is_category() && aura_bridge_get_template(get_queried_object_id());
  if (!$load && is_singular()) {
    $post = get_post();
    $content = $post ? (string)$post->post_content : '';
    $load = strpos($content,'aura-site-shell') !== false || strpos($content,'aura-resource-shell') !== false;
  }
  if($load) wp_enqueue_style('aura-site-bridge',AURA_BRIDGE_URL.'assets/aura-site.css',[],AURA_BRIDGE_VERSION);
});

add_filter('template_include', function($template){
  if(!is_category()) return $template;
  $id=get_queried_object_id(); $tpl=aura_bridge_get_template($id); if(!$tpl) return $template;
  $mode=get_term_meta($id,'aura_template_mode',true) ?: ($tpl['mode'] ?? 'full');
  if($mode==='full') return AURA_BRIDGE_DIR.'templates/category-aura.php';
  return $template;
}, 99);

// Safe header mode: inject structured content above the theme's normal archive without putting CSS in the category description.
add_action('loop_start', function($query){
  if(is_admin() || !is_category() || !$query->is_main_query()) return;
  $id=get_queried_object_id(); $tpl=aura_bridge_get_template($id); if(!$tpl) return;
  $mode=get_term_meta($id,'aura_template_mode',true) ?: ($tpl['mode'] ?? 'full');
  if($mode==='header') echo aura_bridge_render_template($tpl,false);
}, 1);

function aura_bridge_card_placeholder($label='Guide'){
  return '<div class="aura-card-media"><span>'.esc_html($label).'</span></div>';
}
function aura_bridge_item($raw){
  $raw=trim((string)$raw); $pos=strrpos($raw,'|');
  if($pos!==false){$title=trim(substr($raw,0,$pos));$url=trim(substr($raw,$pos+1));if(filter_var($url,FILTER_VALIDATE_URL) || strpos($url,'/')===0) return [$title,$url];}
  return [$raw,''];
}
function aura_bridge_render_blocks($blocks){
  $out='';
  foreach($blocks as $b){
    $type=$b['type'] ?? 'grid'; $title=$b['title'] ?? ''; $text=$b['text'] ?? ''; $items=$b['items'] ?? [];
    if($type==='feature'){
      $out.='<section class="aura-feature"><div class="aura-feature-media"></div><div class="aura-feature-copy"><span class="aura-kicker">FEATURED</span><h2>'.esc_html($title).'</h2><p>'.esc_html($text).'</p></div></section>';
    } elseif($type==='pills'){
      $out.='<section class="aura-section"><h2>'.esc_html($title).'</h2><div class="aura-pills">'; foreach($items as $i){[$it,$iu]=aura_bridge_item($i);$out.= $iu?'<a href="'.esc_url($iu).'"><span>'.esc_html($it).'</span></a>':'<span>'.esc_html($it).'</span>';} $out.='</div></section>';
    } elseif($type==='rank'){
      $out.='<section class="aura-section"><h2>'.esc_html($title).'</h2><div class="aura-rank">'; $n=1; foreach($items as $i){[$it,$iu]=aura_bridge_item($i);$txt=$iu?'<a href="'.esc_url($iu).'">'.esc_html($it).'</a>':esc_html($it);$out.='<div><b>'.str_pad((string)$n++,2,'0',STR_PAD_LEFT).'</b><span>'.$txt.'</span></div>';} $out.='</div></section>';
    } elseif($type==='steps'){
      $out.='<section class="aura-section"><h2>'.esc_html($title).'</h2><div class="aura-steps">'; $n=1; foreach($items as $i)$out.='<div><b>'.$n++.'</b><span>'.esc_html($i).'</span></div>'; $out.='</div></section>';
    } elseif($type==='quote'){
      $out.='<blockquote class="aura-quote">'.esc_html($text ?: $title).'</blockquote>';
    } elseif($type==='cta'){
      $cta_url=!empty($b['url'])?esc_url($b['url']):'#aura-posts';$cta_label=!empty($b['button'])?esc_html($b['button']):'Explore guides';$out.='<section class="aura-cta"><div><span class="aura-kicker">MINDFUL ADAPTION</span><h2>'.esc_html($title).'</h2><p>'.esc_html($text).'</p></div><a href="'.$cta_url.'">'.$cta_label.'</a></section>'; 
    } else {
      $out.='<section class="aura-section"><h2>'.esc_html($title).'</h2>'; if($text)$out.='<p class="aura-section-lead">'.esc_html($text).'</p>'; $out.='<div class="aura-grid">'; foreach($items as $i){[$it,$iu]=aura_bridge_item($i);$link=$iu?'<a class="aura-card-link" href="'.esc_url($iu).'">Read guide →</a>':'<span class="aura-card-link">Read guide →</span>';$out.='<article class="aura-card">'.aura_bridge_card_placeholder('GUIDE').'<h3>'.esc_html($it).'</h3><p>Practical guidance with clear next steps and useful takeaways.</p>'.$link.'</article>';} $out.='</div></section>';
    }
  }
  return $out;
}
function aura_bridge_render_affiliates($aff){
  if(empty($aff)) return '';
  $o='<aside class="aura-affiliates" aria-label="Recommended resources"><div class="aura-affiliate-sticky"><span class="aura-kicker">RECOMMENDED</span>';
  foreach($aff as $a){ if(empty($a['url']) && empty($a['title'])) continue; $o.='<article class="aura-affiliate-card">'; if(!empty($a['image']))$o.='<img src="'.esc_url($a['image']).'" alt="">'; $o.='<small>'.esc_html($a['label'] ?: 'Recommended').'</small><h3>'.esc_html($a['title']).'</h3><p>'.esc_html($a['text']).'</p>'; if(!empty($a['url']))$o.='<a rel="sponsored nofollow noopener" target="_blank" href="'.esc_url($a['url']).'">'.esc_html($a['cta'] ?: 'Learn more').' →</a>'; $o.='<em>'.esc_html($a['disclosure'] ?: 'Affiliate link').'</em></article>'; }
  return $o.'</div></aside>';
}
function aura_bridge_render_template($t,$withPosts=true){
  $accent=esc_attr($t['accent'] ?? '#2378d2'); $hero=esc_url($t['hero'] ?? '');
  $style=$hero ? ' style="--aura-accent:'.$accent.';--aura-hero:url(\''.esc_attr($hero).'\')"' : ' style="--aura-accent:'.$accent.'"';
  $o='<div class="aura-site-shell aura-variant-'.esc_attr($t['variant'] ?? 'editorial').'"'.$style.'>';
  $o.='<section class="aura-hero"><div class="aura-container"><span class="aura-kicker">'.esc_html($t['eyebrow'] ?? '').'</span><h1>'.esc_html($t['title'] ?? '').'</h1><p>'.esc_html($t['intro'] ?? '').'</p></div></section>';
  $o.='<div class="aura-layout"><main class="aura-main">'.aura_bridge_render_blocks($t['blocks'] ?? []).'</main>'.aura_bridge_render_affiliates($t['affiliates'] ?? []).'</div>';
  if($withPosts && !empty($t['showNativePosts'])) $o.='<div id="aura-posts" class="aura-native-anchor"></div>';
  return $o.'</div>';
}
