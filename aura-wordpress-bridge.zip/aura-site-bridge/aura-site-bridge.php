<?php
/**
 * Plugin Name: Aura Site Bridge
 * Description: Full WordPress layout bridge for Aura Publisher Pro: category takeovers, resource hubs, affiliate sidebars, template publishing and live diagnostics.
 * Version: 1.1.0
 * Author: Aura Publisher Pro
 */
if (!defined('ABSPATH')) exit;

define('AURA_BRIDGE_VERSION','1.1.0');
define('AURA_BRIDGE_DIR',plugin_dir_path(__FILE__));
define('AURA_BRIDGE_URL',plugin_dir_url(__FILE__));

add_action('init', function(){
  register_term_meta('category','aura_template_json',['type'=>'string','single'=>true,'show_in_rest'=>false,'sanitize_callback'=>'wp_kses_post','auth_callback'=>function(){return current_user_can('edit_posts');}]);
  register_term_meta('category','aura_template_mode',['type'=>'string','single'=>true,'show_in_rest'=>false,'sanitize_callback'=>'sanitize_key','auth_callback'=>function(){return current_user_can('edit_posts');}]);
});

function aura_bridge_can_manage(){ return current_user_can('manage_options') || current_user_can('manage_categories') || current_user_can('edit_pages'); }
function aura_bridge_clean_url($url){ return esc_url_raw(trim((string)$url)); }
function aura_bridge_sanitize_seo($s){
  return ['title'=>sanitize_text_field($s['title'] ?? ''),'description'=>sanitize_textarea_field($s['description'] ?? ''),'canonical'=>aura_bridge_clean_url($s['canonical'] ?? ''),'socialImage'=>aura_bridge_clean_url($s['socialImage'] ?? ''),'schema'=>in_array(($s['schema'] ?? 'WebPage'),['CollectionPage','WebPage','Article','FAQPage'],true)?$s['schema']:'WebPage','robots'=>in_array(($s['robots'] ?? 'index,follow'),['index,follow','noindex,follow','noindex,nofollow'],true)?$s['robots']:'index,follow','breadcrumbs'=>!empty($s['breadcrumbs'])];
}
function aura_bridge_sanitize_affiliate($row){
  return [
    'label'=>sanitize_text_field($row['label'] ?? 'Recommended'),
    'title'=>sanitize_text_field($row['title'] ?? ''),
    'text'=>sanitize_textarea_field($row['text'] ?? ''),
    'url'=>aura_bridge_clean_url($row['url'] ?? ''),
    'image'=>aura_bridge_clean_url($row['image'] ?? ''),
    'cta'=>sanitize_text_field($row['cta'] ?? 'Learn more'),
    'disclosure'=>sanitize_text_field($row['disclosure'] ?? 'Affiliate link'),
  ];
}
function aura_bridge_sanitize_template($in){
  $blocks=[];
  foreach (($in['blocks'] ?? []) as $b){
    $items=[]; foreach (($b['items'] ?? []) as $i) $items[] = sanitize_text_field($i);
    $blocks[]=['type'=>sanitize_key($b['type'] ?? 'grid'),'title'=>sanitize_text_field($b['title'] ?? ''),'text'=>wp_kses_post($b['text'] ?? ''),'items'=>$items,'button'=>sanitize_text_field($b['button'] ?? ''),'url'=>aura_bridge_clean_url($b['url'] ?? ''),'image'=>aura_bridge_clean_url($b['image'] ?? ''),'alt'=>sanitize_text_field($b['alt'] ?? ''),'width'=>sanitize_key($b['width'] ?? 'content'),'align'=>in_array(($b['align'] ?? 'left'),['left','center'],true)?$b['align']:'left','background'=>sanitize_text_field($b['background'] ?? ''),'color'=>sanitize_hex_color($b['color'] ?? '') ?: '','columns'=>max(2,min(4,(int)($b['columns'] ?? 3)))];
  }
  $aff=[]; foreach (($in['affiliates'] ?? []) as $a) $aff[] = aura_bridge_sanitize_affiliate($a);
  return [
    'name'=>sanitize_text_field($in['name'] ?? ''),
    'eyebrow'=>sanitize_text_field($in['eyebrow'] ?? ''),
    'title'=>sanitize_text_field($in['title'] ?? ''),
    'intro'=>sanitize_textarea_field($in['intro'] ?? ''),
    'hero'=>aura_bridge_clean_url($in['hero'] ?? ''),
    'accent'=>sanitize_hex_color($in['accent'] ?? '#2378d2') ?: '#2378d2',
    'variant'=>sanitize_key($in['variant'] ?? 'editorial'),
    'mode'=>in_array(($in['mode'] ?? 'full'),['full','header'],true)?$in['mode']:'full',
    'blocks'=>$blocks,
    'affiliates'=>$aff,
    'showNativePosts'=>!empty($in['showNativePosts']),'contentWidth'=>in_array((string)($in['contentWidth'] ?? '1180'),['1040','1180','1320','1440'],true)?(string)$in['contentWidth']:'1180','density'=>in_array(($in['density'] ?? 'balanced'),['compact','balanced','airy'],true)?$in['density']:'balanced','radius'=>in_array((string)($in['radius'] ?? '20'),['0','12','20','28'],true)?(string)$in['radius']:'20','fontPair'=>in_array(($in['fontPair'] ?? 'modern'),['modern','editorial','clean'],true)?$in['fontPair']:'modern','seo'=>aura_bridge_sanitize_seo((array)($in['seo'] ?? [])),
  ];
}
function aura_bridge_get_template($term_id){
  $raw=get_term_meta($term_id,'aura_template_json',true);
  if(!$raw) return null;
  $d=json_decode($raw,true); return is_array($d)?$d:null;
}

add_action('rest_api_init', function(){
  register_rest_route('aura/v1','/ping',[
    'methods'=>'GET','permission_callback'=>'__return_true','callback'=>function(){ return rest_ensure_response(['ok'=>true,'installed'=>true,'version'=>AURA_BRIDGE_VERSION,'capabilities'=>['category_takeover'=>true,'affiliate_sidebar'=>true,'resource_templates'=>true,'page_styles'=>true,'seo_meta'=>true,'responsive_builder'=>true]]); }
  ]);
  register_rest_route('aura/v1','/status',[
    'methods'=>'GET','permission_callback'=>'__return_true','callback'=>function(){
      return rest_ensure_response(['ok'=>true,'installed'=>true,'version'=>AURA_BRIDGE_VERSION,'capabilities'=>['category_takeover'=>true,'affiliate_sidebar'=>true,'resource_templates'=>true,'page_styles'=>true,'diagnostics'=>true,'seo_meta'=>true,'responsive_builder'=>true]]);
    }
  ]);
  register_rest_route('aura/v1','/category/(?P<id>\d+)/template',[
    'methods'=>'POST','permission_callback'=>'aura_bridge_can_manage','callback'=>function(WP_REST_Request $r){
      $id=(int)$r['id']; $term=get_term($id,'category'); if(!$term || is_wp_error($term)) return new WP_Error('aura_bad_category','Category not found',['status'=>404]);
      $tpl=aura_bridge_sanitize_template((array)$r->get_json_params());
      update_term_meta($id,'aura_template_json',wp_json_encode($tpl));
      update_term_meta($id,'aura_template_mode',$tpl['mode']);
      // Remove legacy CSS-as-description so it can never show as raw text again.
      if (strpos((string)$term->description,'.aura-site-template') !== false || strpos((string)$term->description,'<style') !== false) {
        wp_update_term($id,'category',['description'=>'']);
      }
      return rest_ensure_response(['ok'=>true,'id'=>$id,'mode'=>$tpl['mode'],'link'=>get_category_link($id)]);
    }
  ]);
  register_rest_route('aura/v1','/category/(?P<id>\d+)/template',[
    'methods'=>'DELETE','permission_callback'=>'aura_bridge_can_manage','callback'=>function(WP_REST_Request $r){ delete_term_meta((int)$r['id'],'aura_template_json'); delete_term_meta((int)$r['id'],'aura_template_mode'); return ['ok'=>true]; }
  ]);
  register_rest_route('aura/v1','/diagnostics',[
    'methods'=>'GET','permission_callback'=>'aura_bridge_can_manage','callback'=>function(){
      global $wp_version; $theme=wp_get_theme();
      return rest_ensure_response(['ok'=>true,'wordpress'=>$wp_version,'php'=>PHP_VERSION,'theme'=>$theme->get('Name'),'theme_version'=>$theme->get('Version'),'permalinks'=>(bool)get_option('permalink_structure'),'rest'=>true,'uploads'=>wp_upload_dir()['basedir'],'max_upload'=>wp_max_upload_size()]);
    }
  ]);
  register_rest_route('aura/v1','/post/(?P<id>\d+)/seo',[
    'methods'=>'POST','permission_callback'=>function(WP_REST_Request $r){ return current_user_can('edit_post',(int)$r['id']); },'callback'=>function(WP_REST_Request $r){
      $id=(int)$r['id']; if(!get_post($id)) return new WP_Error('aura_bad_post','Post not found',['status'=>404]);
      $seo=aura_bridge_sanitize_seo((array)$r->get_json_params()); update_post_meta($id,'_aura_seo_json',wp_json_encode($seo)); return rest_ensure_response(['ok'=>true,'id'=>$id]);
    }
  ]);

});


function aura_bridge_output_seo($seo,$title=''){
  if(empty($seo) || !is_array($seo)) return;
  $st=trim((string)($seo['title'] ?? '')); $desc=trim((string)($seo['description'] ?? '')); $canon=trim((string)($seo['canonical'] ?? '')); $img=trim((string)($seo['socialImage'] ?? '')); $robots=$seo['robots'] ?? 'index,follow';
  if($desc) echo "\n<meta name=\"description\" content=\"".esc_attr($desc)."\">"; if($robots) echo "\n<meta name=\"robots\" content=\"".esc_attr($robots)."\">"; if($canon) echo "\n<link rel=\"canonical\" href=\"".esc_url($canon)."\">";
  $ogt=$st ?: $title; if($ogt) echo "\n<meta property=\"og:title\" content=\"".esc_attr($ogt)."\">"; if($desc) echo "\n<meta property=\"og:description\" content=\"".esc_attr($desc)."\">"; if($img) echo "\n<meta property=\"og:image\" content=\"".esc_url($img)."\">";
  $schema=['@context'=>'https://schema.org','@type'=>$seo['schema'] ?? 'WebPage','name'=>$ogt ?: $title,'description'=>$desc]; if($canon)$schema['url']=$canon; if($img)$schema['image']=$img; echo "\n<script type=\"application/ld+json\">".wp_json_encode(array_filter($schema))."</script>";
}
add_action('wp_head',function(){
  if(is_category()){ $t=aura_bridge_get_template(get_queried_object_id()); if($t && !empty($t['seo'])) aura_bridge_output_seo($t['seo'],$t['title'] ?? single_cat_title('',false)); }
  elseif(is_singular()){ $raw=get_post_meta(get_queried_object_id(),'_aura_seo_json',true); $seo=$raw?json_decode($raw,true):null; if(is_array($seo)) aura_bridge_output_seo($seo,get_the_title()); }
},3);
add_filter('pre_get_document_title',function($title){
  if(is_category()){ $t=aura_bridge_get_template(get_queried_object_id()); if(!empty($t['seo']['title'])) return $t['seo']['title']; }
  elseif(is_singular()){ $raw=get_post_meta(get_queried_object_id(),'_aura_seo_json',true);$seo=$raw?json_decode($raw,true):null;if(!empty($seo['title'])) return $seo['title']; }
  return $title;
},20);

add_action('wp_enqueue_scripts', function(){
  $load = is_category() && aura_bridge_get_template(get_queried_object_id());
  if (!$load && is_singular()) {
    $post = get_post();
    $content = $post ? (string)$post->post_content : '';
    $load = strpos($content,'aura-site-shell') !== false || strpos($content,'aura-resource-shell') !== false;
  }
  if($load) wp_enqueue_style('aura-site-bridge',AURA_BRIDGE_URL.'assets/aura-site.css',[],AURA_BRIDGE_VERSION);
});

add_filter('template_include', function($template){
  if(!is_category()) return $template;
  $id=get_queried_object_id(); $tpl=aura_bridge_get_template($id); if(!$tpl) return $template;
  $mode=get_term_meta($id,'aura_template_mode',true) ?: ($tpl['mode'] ?? 'full');
  if($mode==='full') return AURA_BRIDGE_DIR.'templates/category-aura.php';
  return $template;
}, 99);

// Safe header mode: inject structured content above the theme's normal archive without putting CSS in the category description.
add_action('loop_start', function($query){
  if(is_admin() || !is_category() || !$query->is_main_query()) return;
  $id=get_queried_object_id(); $tpl=aura_bridge_get_template($id); if(!$tpl) return;
  $mode=get_term_meta($id,'aura_template_mode',true) ?: ($tpl['mode'] ?? 'full');
  if($mode==='header') echo aura_bridge_render_template($tpl,false);
}, 1);

function aura_bridge_card_placeholder($label='Guide'){
  return '<div class="aura-card-media"><span>'.esc_html($label).'</span></div>';
}
function aura_bridge_item($raw){
  $raw=trim((string)$raw); $pos=strrpos($raw,'|');
  if($pos!==false){$title=trim(substr($raw,0,$pos));$url=trim(substr($raw,$pos+1));if(filter_var($url,FILTER_VALIDATE_URL) || strpos($url,'/')===0) return [$title,$url];}
  return [$raw,''];
}
function aura_bridge_section_open($b,$extra=''){
  $w=in_array(($b['width'] ?? 'content'),['full','content','narrow'],true)?$b['width']:'content'; $align=($b['align'] ?? 'left')==='center'?' center':''; $style='';
  if(!empty($b['background'])) $style.='background:'.esc_attr($b['background']).';'; if(!empty($b['color'])) $style.='color:'.esc_attr($b['color']).';';
  return '<section class="aura-section aura-section--'.esc_attr($w).$align.' '.$extra.'"'.($style?' style="'.$style.'"':'').'>';
}
function aura_bridge_render_blocks($blocks){
  $out='';
  foreach($blocks as $b){
    $type=$b['type'] ?? 'grid'; $title=$b['title'] ?? ''; $text=$b['text'] ?? ''; $items=$b['items'] ?? []; $img=$b['image'] ?? ''; $alt=$b['alt'] ?? '';
    if($type==='feature'){
      $media=$img?'<div class="aura-feature-media"><img src="'.esc_url($img).'" alt="'.esc_attr($alt).'" loading="lazy"></div>':'<div class="aura-feature-media"></div>';
      $out.='<section class="aura-feature">'.$media.'<div class="aura-feature-copy"><span class="aura-kicker">FEATURED</span><h2>'.esc_html($title).'</h2><div class="aura-rich">'.wp_kses_post(wpautop($text)).'</div>'.(!empty($b['url'])?'<a class="aura-inline-cta" href="'.esc_url($b['url']).'">'.esc_html($b['button'] ?: 'Read more').' →</a>':'').'</div></section>';
    } elseif($type==='topics'){
      $out.=aura_bridge_section_open($b).'<h2>'.esc_html($title).'</h2><div class="aura-pills">'; foreach($items as $i){[$it,$iu]=aura_bridge_item($i);$out.= $iu?'<a href="'.esc_url($iu).'"><span>'.esc_html($it).'</span></a>':'<span>'.esc_html($it).'</span>';} $out.='</div></section>';
    } elseif(in_array($type,['grid','resources','stats'],true)){
      $cols=max(2,min(4,(int)($b['columns'] ?? 3))); $out.=aura_bridge_section_open($b,'aura-cards-'.$type).'<h2>'.esc_html($title).'</h2>'; if($text)$out.='<div class="aura-section-lead">'.wp_kses_post(wpautop($text)).'</div>'; $out.='<div class="aura-grid" style="--aura-cols:'.$cols.'">';
      foreach($items as $i){[$it,$iu]=aura_bridge_item($i);$label=$type==='resources'?'RESOURCE':($type==='stats'?'HIGHLIGHT':'GUIDE');$link=$iu?'<a class="aura-card-link" href="'.esc_url($iu).'">'.($type==='resources'?'Open resource':'Read guide').' →</a>':'';$out.='<article class="aura-card">'.aura_bridge_card_placeholder($label).'<h3>'.esc_html($it).'</h3>'.$link.'</article>'; } $out.='</div></section>';
    } elseif($type==='list'){
      $out.=aura_bridge_section_open($b).'<h2>'.esc_html($title).'</h2><div class="aura-rank">'; $n=1; foreach($items as $i){[$it,$iu]=aura_bridge_item($i);$txt=$iu?'<a href="'.esc_url($iu).'">'.esc_html($it).'</a>':esc_html($it);$out.='<div><b>'.str_pad((string)$n++,2,'0',STR_PAD_LEFT).'</b><span>'.$txt.'</span></div>';} $out.='</div></section>';
    } elseif($type==='steps'){
      $out.=aura_bridge_section_open($b).'<h2>'.esc_html($title).'</h2><div class="aura-steps">'; $n=1; foreach($items as $i)$out.='<div><b>'.$n++.'</b><span>'.esc_html($i).'</span></div>'; $out.='</div></section>';
    } elseif($type==='text'){
      $out.=aura_bridge_section_open($b,'aura-rich-section').($title?'<h2>'.esc_html($title).'</h2>':'').'<div class="aura-rich">'.wp_kses_post(wpautop($text)).'</div></section>';
    } elseif($type==='image'){
      $out.=aura_bridge_section_open($b,'aura-image-section').($title?'<h2>'.esc_html($title).'</h2>':'').($img?'<img src="'.esc_url($img).'" alt="'.esc_attr($alt).'" loading="lazy">':'').($text?'<div class="aura-rich">'.wp_kses_post(wpautop($text)).'</div>':'').'</section>';
    } elseif($type==='faq'){
      $out.=aura_bridge_section_open($b,'aura-faq').'<h2>'.esc_html($title).'</h2>'; foreach($items as $i){$parts=array_map('trim',explode('|',$i,2));$q=$parts[0]??'';$a=$parts[1]??'';$out.='<details><summary>'.esc_html($q).'</summary><div>'.esc_html($a).'</div></details>';}$out.='</section>';
    } elseif($type==='newsletter'){
      $out.='<section class="aura-newsletter"><div><span class="aura-kicker">STAY IN THE LOOP</span><h2>'.esc_html($title).'</h2><div>'.wp_kses_post(wpautop($text)).'</div></div>'.(!empty($b['url'])?'<a href="'.esc_url($b['url']).'">'.esc_html($b['button'] ?: 'Join / subscribe').' →</a>':'').'</section>';
    } elseif($type==='quote'){
      $out.='<blockquote class="aura-quote">'.esc_html(wp_strip_all_tags($text ?: $title)).'</blockquote>';
    } elseif($type==='cta'){
      $cta_url=!empty($b['url'])?esc_url($b['url']):'#aura-posts';$cta_label=!empty($b['button'])?esc_html($b['button']):'Explore guides';$out.='<section class="aura-cta"><div><span class="aura-kicker">EXPLORE MORE</span><h2>'.esc_html($title).'</h2><div>'.wp_kses_post(wpautop($text)).'</div></div><a href="'.$cta_url.'">'.$cta_label.'</a></section>';
    } elseif($type==='divider'){ $out.='<hr class="aura-divider">'; }
      elseif($type==='spacer'){ $out.='<div class="aura-spacer" aria-hidden="true"></div>'; }
  }
  return $out;
}
function aura_bridge_render_affiliates($aff){
  if(empty($aff)) return '';
  $o='<aside class="aura-affiliates" aria-label="Recommended resources"><div class="aura-affiliate-sticky"><span class="aura-kicker">RECOMMENDED</span>';
  foreach($aff as $a){ if(empty($a['url']) && empty($a['title'])) continue; $o.='<article class="aura-affiliate-card">'; if(!empty($a['image']))$o.='<img src="'.esc_url($a['image']).'" alt="">'; $o.='<small>'.esc_html($a['label'] ?: 'Recommended').'</small><h3>'.esc_html($a['title']).'</h3><p>'.esc_html($a['text']).'</p>'; if(!empty($a['url']))$o.='<a rel="sponsored nofollow noopener" target="_blank" href="'.esc_url($a['url']).'">'.esc_html($a['cta'] ?: 'Learn more').' →</a>'; $o.='<em>'.esc_html($a['disclosure'] ?: 'Affiliate link').'</em></article>'; }
  return $o.'</div></aside>';
}
function aura_bridge_render_template($t,$withPosts=true){
  $accent=esc_attr($t['accent'] ?? '#2378d2'); $hero=esc_url($t['hero'] ?? '');
  $cw=esc_attr($t['contentWidth'] ?? '1180');$rad=esc_attr($t['radius'] ?? '20');$density=esc_attr($t['density'] ?? 'balanced');$font=esc_attr($t['fontPair'] ?? 'modern');$vars='--aura-accent:'.$accent.';--aura-content:'.$cw.'px;--aura-radius:'.$rad.'px';$style=$hero ? ' style="'.$vars.';--aura-hero:url(\''.esc_attr($hero).'\')"' : ' style="'.$vars.'"';
  $o='<div class="aura-site-shell aura-variant-'.esc_attr($t['variant'] ?? 'editorial').' aura-density-'.$density.' aura-font-'.$font.'"'.$style.'>';
  $o.='<section class="aura-hero"><div class="aura-container"><span class="aura-kicker">'.esc_html($t['eyebrow'] ?? '').'</span><h1>'.esc_html($t['title'] ?? '').'</h1><p>'.esc_html($t['intro'] ?? '').'</p></div></section>';
  $o.='<div class="aura-layout"><main class="aura-main">'.aura_bridge_render_blocks($t['blocks'] ?? []).'</main>'.aura_bridge_render_affiliates($t['affiliates'] ?? []).'</div>';
  if($withPosts && !empty($t['showNativePosts'])) $o.='<div id="aura-posts" class="aura-native-anchor"></div>';
  return $o.'</div>';
}
